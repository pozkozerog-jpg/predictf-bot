# ⚽ Football Predictor Bot

Telegram-бот для прогнозирования футбольных матчей с самообучающейся ML системой.

## 🎯 Возможности

- 🤖 **ML прогнозы**: 15 моделей (5 лиг × 3 алгоритма: GradientBoosting, RandomForest, XGBoost)
- 📊 **Детальная аналитика**: Статистика команд, H2H, форма, мотивация
- 🔔 **Подписки**: Уведомления за 2 часа до матча любимых команд
- 📈 **Самообучение**: Автоматическая переобучение после 50+ новых результатов
- 🎲 **3 ставки на матч**: Результат, тотал, обе забьют

## 🏆 Поддерживаемые турниры

- Premier League, La Liga, Serie A, Bundesliga, Ligue 1
- Champions League, Europa League
- World Cup + еще 4 турнира

## 🚀 Запуск на Render.com

### 1. Подготовка API ключей

1. Создай бота в [@BotFather](https://t.me/botfather) → получи `TELEGRAM_TOKEN`
2. Зарегистрируйся на [Football-Data.org](https://www.football-data.org/) → получи API ключ
3. Опционально: OpenWeather API, API-Football

### 2. Деплой на Render

**Шаг 1: Создай PostgreSQL базу**
- Dashboard → New → PostgreSQL
- Скопируй `Internal Database URL`

**Шаг 2: Создай Web Service**
- Dashboard → New → Web Service
- Подключи свой GitHub репозиторий
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `python main.py`

**Шаг 3: Добавь переменные окружения**
```
TELEGRAM_TOKEN=ваш_токен
FOOTBALL_DATA_ORG_KEY=ваш_ключ
DATABASE_URL=скопированный_url
OPENWEATHER_API_KEY=ваш_ключ (опционально)
API_FOOTBALL_KEY=ваш_ключ (опционально)
```

**Шаг 4: Deploy!**
- Нажми Create Web Service
- Бот запустится автоматически

### 3. Scheduler (опционально)

Для автоуведомлений создай второй сервис:
- **Start Command**: `python scheduler.py`
- Используй те же переменные окружения

## 📦 Локальный запуск

```bash
# Установка
pip install -r requirements.txt
